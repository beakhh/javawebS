package com.spring.javawebS.vo;

import lombok.Data;

public @Data class InquiryReplyVO {
	private int reIdx;
	private int inquiryIdx;
	private String reWDate;
	private String reContent;
}
