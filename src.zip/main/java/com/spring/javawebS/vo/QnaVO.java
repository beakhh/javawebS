package com.spring.javawebS.vo;

import lombok.Data;

@Data
public class QnaVO {
	private int idx;
	private String qnaIdx;
	private String mid;
	private String nickName;
	private String title;
	private String email;
	private String pwd;
	private String wDate;
	private String content;
	private String qnaSw;
	
	private String diffTime;
}
