package com.spring.javawebS.vo;

import lombok.Data;

@Data
public class TransactionVO {
	private int idx;
	private String mid;
	private String name;
	private int age;
	private String address;
	private String nickName;
	private String job;
}
