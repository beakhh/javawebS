package com.spring.javawebS.vo;

import lombok.Data;

@Data
public class GoodVO {
	private int idx;
	private String part;
	private int partIdx;
	private String mid;
}
