package com.spring.javawebS.vo;

import lombok.Data;

@Data
public class KakaoAddressVO {
	private String address;
	private double latitude;
	private double longitude;
}
