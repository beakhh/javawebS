package com.spring.javawebS.vo;

import lombok.Data;

@Data
public class MainImageVO {
	private int idx;
	private String productCode;
	private String mainFName;
	
	private String productName;
}
