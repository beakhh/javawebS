package com.spring.javawebS.vo;

import lombok.Data;

@Data
public class MailVO {
	private String toMail;
	private String title;
	private String content;
}
